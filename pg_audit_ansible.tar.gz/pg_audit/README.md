# PostgreSQL Access Audit — Ansible Solution

## Project Structure

```
pg_audit/
├── ansible.cfg                        # Ansible config
├── pg_audit_playbook.yml              # Main playbook
├── setup_cron.yml                     # Cron scheduler
│
├── inventory/
│   └── hosts.ini                      # Your servers list
│
├── group_vars/
│   └── pg_servers.yml                 # Shared settings for all servers
│
├── host_vars/
│   ├── prod_server1.yml               # Password + DB list per server
│   ├── prod_server2.yml
│   └── staging_server.yml
│
├── scripts/
│   └── generate_report.py             # Excel report generator
│
└── roles/
    ├── pg_audit/                      # Deploys SQL + collects data
    │   ├── tasks/
    │   │   ├── main.yml
    │   │   └── process_database.yml
    │   └── templates/
    │       └── audit_functions.sql.j2
    └── pg_report/                     # Generates Excel report
        └── tasks/
            └── main.yml
```

---

## Quick Setup (5 steps)

### 1. Install requirements on control node
```bash
pip3 install psycopg2-binary openpyxl pandas
ansible-galaxy collection install community.postgresql   # optional
```

### 2. Add your servers to inventory
Edit `inventory/hosts.ini`:
```ini
[pg_servers]
prod_server1   ansible_host=10.0.0.1   pg_label="Production Server 1"
prod_server2   ansible_host=10.0.0.2   pg_label="Production Server 2"
```

### 3. Add credentials + DB list per server
Edit each `host_vars/<server_name>.yml`:
```yaml
pg_admin_password: "your_password"
pg_databases:
  - app_db
  - billing_db
```

### 4. Set SSH user in group_vars
Edit `group_vars/pg_servers.yml`:
```yaml
ansible_user: your_ssh_user
pg_admin_user: postgres
```

### 5. Create output directory
```bash
sudo mkdir -p /opt/pg_audit/reports /opt/pg_audit/logs
sudo chown -R $USER /opt/pg_audit
```

---

## Running the Audit

### Manual run (all servers)
```bash
ansible-playbook -i inventory/hosts.ini pg_audit_playbook.yml
```

### Manual run (one server only)
```bash
ansible-playbook -i inventory/hosts.ini pg_audit_playbook.yml \
  --limit prod_server1
```

### Collect data only (no report)
```bash
ansible-playbook -i inventory/hosts.ini pg_audit_playbook.yml \
  --tags collect
```

### Generate report only (data already collected)
```bash
ansible-playbook -i inventory/hosts.ini pg_audit_playbook.yml \
  --tags report
```

### Dry run (check mode — no changes made)
```bash
ansible-playbook -i inventory/hosts.ini pg_audit_playbook.yml \
  --check
```

---

## Scheduling

### Install monthly cron job (1st of month, 6AM)
```bash
ansible-playbook setup_cron.yml
```

### Change the schedule
Edit these vars in `setup_cron.yml`:
```yaml
cron_minute:  "0"
cron_hour:    "6"     # Change to desired hour
cron_day:     "1"     # 1 = monthly | * = daily | 1,15 = twice monthly
cron_month:   "*"
cron_weekday: "*"     # 1 = Monday (for weekly runs)
```

### Common schedule examples
| Schedule | minute | hour | day | weekday |
|---|---|---|---|---|
| Daily 6AM | 0 | 6 | * | * |
| Weekly Monday 6AM | 0 | 6 | * | 1 |
| Monthly 1st 6AM | 0 | 6 | 1 | * |
| Every 2 weeks | 0 | 6 | 1,15 | * |

### Remove cron job
```bash
ansible-playbook setup_cron.yml --tags remove
```

---

## Report Output

Reports are saved to `/opt/pg_audit/reports/` with timestamp:
```
pg_access_audit_20260312_060000.xlsx
```

### 4 sheets in the report:

| Sheet | Contents |
|---|---|
| Cover | Summary table — users, schemas, dangerous count per DB |
| Role Memberships | Every user → roles they belong to (DIRECT / INHERITED) |
| Schema Access | Every user → every schema → SELECT/INSERT/UPDATE/DELETE |
| ⚠️ Dangerous Access | Only users with DELETE or TRUNCATE — red highlights |

---

## Adding a New Server

1. Add entry to `inventory/hosts.ini`
2. Create `host_vars/<new_server>.yml` with password and DB list
3. Run the playbook — new server included automatically

---

## Troubleshooting

| Problem | Fix |
|---|---|
| SSH connection refused | Check `ansible_user` and SSH key in `group_vars/pg_servers.yml` |
| psql authentication failed | Check `pg_admin_password` in `host_vars/<server>.yml` |
| Function deploy fails | Ensure `pg_admin_user` has SUPERUSER or CREATEROLE |
| No data in report | Check CSV files in `/opt/pg_audit/reports/data/` |
| pip install fails | Run with `--become` flag or pre-install manually |
