#!/usr/bin/env python3
"""
PostgreSQL Audit Report Generator
Called by Ansible after all CSV data has been collected.
Merges CSVs from all servers/DBs into one Excel report.
"""

import argparse
import glob
import os
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from datetime import datetime

# ── Colour palette ────────────────────────────────────────────
C_DARK_BLUE  = "1F3864"
C_MID_BLUE   = "2E75B6"
C_LIGHT_BLUE = "D6E4F0"
C_RED        = "C00000"
C_GREEN      = "2D7600"
C_GREY       = "F2F2F2"
C_WHITE      = "FFFFFF"
C_YELLOW     = "FFF2CC"

def fill(c):    return PatternFill("solid", fgColor=c)
def af(s=11,b=True,c=C_WHITE): return Font(name="Arial",bold=b,size=s,color=c)
def df(b=False,c="000000"):     return Font(name="Arial",bold=b,size=10,color=c)
def ctr(): return Alignment(horizontal="center",vertical="center",wrap_text=True)
def lft(): return Alignment(horizontal="left",  vertical="center",wrap_text=True)
def bdr():
    s = Side(style="thin", color="BFBFBF")
    return Border(left=s,right=s,top=s,bottom=s)

def write_header(ws, headers, row=1, bg=C_DARK_BLUE):
    for col, h in enumerate(headers, 1):
        c = ws.cell(row=row, column=col, value=h)
        c.font=af(); c.fill=fill(bg); c.alignment=ctr(); c.border=bdr()
    ws.row_dimensions[row].height = 20

def style_row(ws, r, ncols, alt=False):
    for col in range(1, ncols+1):
        c = ws.cell(row=r, column=col)
        c.fill=fill(C_GREY if alt else C_WHITE)
        c.font=df(); c.alignment=lft(); c.border=bdr()

def col_widths(ws, widths):
    for i,w in enumerate(widths,1):
        ws.column_dimensions[get_column_letter(i)].width = w

# ── Load and merge all CSVs ───────────────────────────────────
def load_data(data_dir):
    membership_cols = ["server","database","login_role","member_of_role",
                       "access_type","can_login","is_superuser"]
    schema_cols     = ["server","database","login_role","access_via_role",
                       "access_type","schema_name","schema_privileges",
                       "tables_accessible","can_select","can_insert",
                       "can_update","can_delete","can_truncate"]

    m_frames, s_frames = [], []

    for f in sorted(glob.glob(f"{data_dir}/membership_*.csv")):
        try:
            df = pd.read_csv(f, header=None, names=membership_cols)
            m_frames.append(df)
        except Exception as e:
            print(f"  WARN: skipping {f}: {e}")

    for f in sorted(glob.glob(f"{data_dir}/schema_*.csv")):
        try:
            df = pd.read_csv(f, header=None, names=schema_cols)
            s_frames.append(df)
        except Exception as e:
            print(f"  WARN: skipping {f}: {e}")

    membership = pd.concat(m_frames, ignore_index=True) if m_frames else pd.DataFrame(columns=membership_cols)
    schema     = pd.concat(s_frames, ignore_index=True) if s_frames else pd.DataFrame(columns=schema_cols)

    # Normalise YES/NO columns to uppercase
    for col in ["can_select","can_insert","can_update","can_delete","can_truncate"]:
        if col in schema.columns:
            schema[col] = schema[col].str.upper().fillna("NO")

    return membership, schema

# ── Sheet: Cover ──────────────────────────────────────────────
def build_cover(wb, membership, schema, timestamp):
    ws = wb.active
    ws.title = "Cover"
    ws.sheet_view.showGridLines = False

    ws.merge_cells("A1:H1")
    t = ws["A1"]
    t.value     = "PostgreSQL Access Audit Report"
    t.font      = Font(name="Arial",bold=True,size=22,color=C_WHITE)
    t.fill      = fill(C_DARK_BLUE)
    t.alignment = ctr()
    ws.row_dimensions[1].height = 50

    ws.merge_cells("A2:H2")
    s = ws["A2"]
    s.value     = f"Generated: {timestamp}   |   Servers: {membership['server'].nunique()}   |   Databases: {membership['database'].nunique()}   |   Login Users: {membership['login_role'].nunique()}"
    s.font      = Font(name="Arial",size=11,color=C_WHITE)
    s.fill      = fill(C_MID_BLUE)
    s.alignment = ctr()
    ws.row_dimensions[2].height = 22

    # Section guide
    ws.merge_cells("A4:H4")
    ws["A4"].value     = "Report Contents"
    ws["A4"].font      = af(size=12)
    ws["A4"].fill      = fill(C_MID_BLUE)
    ws["A4"].alignment = ctr()
    ws.row_dimensions[4].height = 22

    contents = [
        ("📊  Summary",           "High-level count of users, schemas, and dangerous access per server/database"),
        ("👥  Role Memberships",   "Every login user and which roles they belong to (DIRECT & INHERITED)"),
        ("🔐  Schema Access",      "What each user can do in each schema — SELECT / INSERT / UPDATE / DELETE"),
        ("⚠️   Dangerous Access",  "Users with DELETE or TRUNCATE — needs management review"),
    ]
    for i, (sheet, desc) in enumerate(contents, 5):
        ws.row_dimensions[i].height = 20
        ws.merge_cells(f"A{i}:C{i}")
        ws[f"A{i}"].value = sheet
        ws[f"A{i}"].font  = df(bold=True)
        ws[f"A{i}"].fill  = fill(C_LIGHT_BLUE if i%2==0 else C_WHITE)
        ws[f"A{i}"].alignment = lft()
        ws[f"A{i}"].border = bdr()
        ws.merge_cells(f"D{i}:H{i}")
        ws[f"D{i}"].value = desc
        ws[f"D{i}"].font  = df()
        ws[f"D{i}"].fill  = fill(C_LIGHT_BLUE if i%2==0 else C_WHITE)
        ws[f"D{i}"].alignment = lft()
        ws[f"D{i}"].border = bdr()

    # Summary table per DB
    ws.merge_cells("A10:H10")
    ws["A10"].value     = "Database Summary"
    ws["A10"].font      = af(size=12)
    ws["A10"].fill      = fill(C_MID_BLUE)
    ws["A10"].alignment = ctr()
    ws.row_dimensions[10].height = 22

    hdrs = ["Server","Database","Login Users","Role Memberships",
            "Schema-User Pairs","Schemas Accessible","Dangerous (DELETE/TRUNCATE)","Status"]
    write_header(ws, hdrs, row=11)

    # Build per-db summary
    dbs = schema.groupby(["server","database"])
    row = 12
    for (srv, db), grp in dbs:
        style_row(ws, row, len(hdrs), alt=(row%2==0))
        m_grp  = membership[(membership["server"]==srv) & (membership["database"]==db)]
        danger = grp[(grp["can_delete"]=="YES") | (grp["can_truncate"]=="YES")]

        vals = [
            srv, db,
            int(m_grp["login_role"].nunique()),
            int(len(m_grp)),
            int(len(grp)),
            int(grp["schema_name"].nunique()),
            int(len(danger)),
            "✅ OK"
        ]
        for col, v in enumerate(vals, 1):
            c = ws.cell(row=row, column=col, value=v)
            if col in (3,4,5,6,7): c.alignment = ctr()
            if col == 7 and isinstance(v,int) and v > 0:
                c.font = df(bold=True, c=C_RED)
        row += 1

    col_widths(ws, [28,18,13,17,17,18,26,10])

# ── Sheet: Role Memberships ───────────────────────────────────
def build_membership(wb, membership):
    ws = wb.create_sheet("Role Memberships")
    ws.sheet_view.showGridLines = False

    hdrs = ["Server","Database","Login Role","Member Of Role",
            "Access Type","Can Login","Is Superuser"]
    write_header(ws, hdrs, bg=C_MID_BLUE)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions

    for i, (_, row) in enumerate(membership.iterrows(), 2):
        style_row(ws, i, len(hdrs), alt=(i%2==0))
        vals = [row["server"], row["database"], row["login_role"],
                row["member_of_role"], row["access_type"],
                row["can_login"], row["is_superuser"]]
        for col, v in enumerate(vals, 1):
            c = ws.cell(row=i, column=col, value=str(v) if pd.notna(v) else "")
            if col == 5:  # Access Type badge
                c.alignment = ctr()
                if str(v) == "DIRECT":
                    c.fill = fill("D5E8D4"); c.font = df(bold=True, c="2D7600")
                else:
                    c.fill = fill("DAE8FC"); c.font = df(bold=True, c="0050EF")
            if col == 7 and str(v).upper() == "YES":  # Superuser = warning
                c.fill = fill(C_YELLOW); c.font = df(bold=True, c=C_RED); c.alignment=ctr()
            if col in (6,7): c.alignment = ctr()

    col_widths(ws, [28,18,22,24,14,12,14])

# ── Sheet: Schema Access ──────────────────────────────────────
def build_schema(wb, schema):
    ws = wb.create_sheet("Schema Access")
    ws.sheet_view.showGridLines = False

    hdrs = ["Server","Database","Login Role","Access Via Role",
            "Access Type","Schema","Schema Privileges",
            "Tables Accessible","SELECT","INSERT","UPDATE","DELETE","TRUNCATE"]
    write_header(ws, hdrs, bg=C_MID_BLUE)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions

    priv_cols = {9:"SELECT",10:"INSERT",11:"UPDATE",12:"DELETE",13:"TRUNCATE"}

    for i, (_, row) in enumerate(schema.iterrows(), 2):
        style_row(ws, i, len(hdrs), alt=(i%2==0))
        vals = [row["server"], row["database"], row["login_role"],
                row["access_via_role"], row["access_type"], row["schema_name"],
                row.get("schema_privileges",""), row.get("tables_accessible",0),
                row["can_select"], row["can_insert"], row["can_update"],
                row["can_delete"], row["can_truncate"]]
        for col, v in enumerate(vals, 1):
            c = ws.cell(row=i, column=col, value=str(v) if pd.notna(v) else "")
            if col == 5:
                c.alignment = ctr()
                if str(v)=="DIRECT":
                    c.fill=fill("D5E8D4"); c.font=df(bold=True,c="2D7600")
                else:
                    c.fill=fill("DAE8FC"); c.font=df(bold=True,c="0050EF")
            if col == 8: c.alignment = ctr()
            if col in priv_cols:
                c.alignment = ctr()
                if str(v).upper() == "YES":
                    if col in (12,13):  # DELETE/TRUNCATE = red
                        c.fill=fill("FFD7D7"); c.font=df(bold=True,c=C_RED)
                    else:
                        c.fill=fill("D5E8D4"); c.font=df(bold=True,c=C_GREEN)
                else:
                    c.fill=fill(C_GREY); c.font=df(c="AAAAAA")

    col_widths(ws, [28,16,20,20,14,18,18,10,9,9,9,9,10])

# ── Sheet: Dangerous Access ───────────────────────────────────
def build_dangerous(wb, schema):
    ws = wb.create_sheet("⚠️ Dangerous Access")
    ws.sheet_view.showGridLines = False

    ws.merge_cells("A1:K1")
    b = ws["A1"]
    b.value     = "⚠️  ATTENTION — Users below have DELETE or TRUNCATE privileges. Please review and confirm these are intentional."
    b.font      = Font(name="Arial",bold=True,size=11,color=C_WHITE)
    b.fill      = fill(C_RED)
    b.alignment = ctr()
    ws.row_dimensions[1].height = 26

    hdrs = ["Server","Database","Login Role","Access Via Role","Access Type",
            "Schema","Tables Accessible","SELECT","INSERT","UPDATE","DELETE","TRUNCATE"]
    write_header(ws, hdrs, row=2, bg="7B0000")
    ws.freeze_panes = "A3"

    dangerous = schema[(schema["can_delete"]=="YES") | (schema["can_truncate"]=="YES")].copy()

    if dangerous.empty:
        ws.merge_cells("A3:L3")
        ws["A3"].value     = "✅  No users found with DELETE or TRUNCATE privileges."
        ws["A3"].font      = Font(name="Arial",bold=True,size=11,color=C_GREEN)
        ws["A3"].fill      = fill("D5E8D4")
        ws["A3"].alignment = ctr()
    else:
        for i, (_, row) in enumerate(dangerous.iterrows(), 3):
            style_row(ws, i, len(hdrs), alt=(i%2==0))
            vals = [row["server"], row["database"], row["login_role"],
                    row["access_via_role"], row["access_type"], row["schema_name"],
                    row.get("tables_accessible",0),
                    row["can_select"], row["can_insert"], row["can_update"],
                    row["can_delete"], row["can_truncate"]]
            for col, v in enumerate(vals, 1):
                c = ws.cell(row=i, column=col, value=str(v) if pd.notna(v) else "")
                if col in (8,9,10,11,12):
                    c.alignment = ctr()
                    if str(v).upper()=="YES":
                        if col in (11,12):
                            c.fill=fill("FFD7D7"); c.font=df(bold=True,c=C_RED)
                        else:
                            c.fill=fill("D5E8D4"); c.font=df(bold=True,c=C_GREEN)
                    else:
                        c.fill=fill(C_GREY); c.font=df(c="AAAAAA")
                if col == 7: c.alignment=ctr()
                if col == 5:
                    c.alignment=ctr()

    col_widths(ws, [28,16,20,20,14,18,10,9,9,9,9,10])

# ── Main ──────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir",   required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--timestamp",  required=True)
    args = parser.parse_args()

    print(f"\n{'='*55}")
    print(f"  PostgreSQL Audit Report Generator")
    print(f"  Timestamp : {args.timestamp}")
    print(f"  Data dir  : {args.data_dir}")
    print(f"{'='*55}")

    print("  Loading CSV data...")
    membership, schema = load_data(args.data_dir)
    print(f"  Membership rows : {len(membership)}")
    print(f"  Schema rows     : {len(schema)}")

    output_file = os.path.join(args.output_dir,
                               f"pg_access_audit_{args.timestamp}.xlsx")

    print("  Building Excel report...")
    wb = Workbook()
    build_cover(wb, membership, schema, args.timestamp)
    build_membership(wb, membership)
    build_schema(wb, schema)
    build_dangerous(wb, schema)

    wb.save(output_file)

    dangerous_count = len(schema[(schema["can_delete"]=="YES") |
                                  (schema["can_truncate"]=="YES")])
    print(f"\n{'='*55}")
    print(f"  ✅  Report saved : {output_file}")
    print(f"  Login users     : {membership['login_role'].nunique()}")
    print(f"  Databases       : {membership['database'].nunique()}")
    print(f"  Dangerous rows  : {dangerous_count}")
    print(f"{'='*55}\n")


if __name__ == "__main__":
    main()
